# About
![tokens with nametag sample image](https://github.com/kibkibe/roll20_api_scripts/blob/master/token_offensive_madness/brochure_named.png)
![tokens without nametag sample image](https://github.com/kibkibe/roll20_api_scripts/blob/master/token_offensive_madness/brochure_nonamed.png)





# Features
- **Size**
  - nametag: 170 x 170px
  - no-nametag: 140 x 140px
- **Color**
  - Black/White   
- **Archetypes**
  - Spirit, Blade, Nightmare
  - Knight, Maiden, Chariot
  - Lord, Legion
  - Kingdom
  - Daemon
  - (+ Abyssal Gate)
   




# License FAQ
- **이 토큰은 아래의 상용/프리소스를 이용하여 제작되었습니다.**
  - [Sacred Geometry Vector Bundle by. Skybox Creative](https://creativemarket.com/skyboxcreative/349504-Sacred-Geometry-Vector-Bundle)
  - Brush: [Ady's Splatter Brushes](https://www.deviantart.com/ady333/art/Ady-s-Splatter-Brushes-26360711)
  - Font: Niveau Grotesk


- **토큰 이미지를 재가공하여 배포해도 되나요?**


**아니오.** 편집자인 저의 2차 저작권과 원본 상용소스의 이용권을 침해하게 됩니다. 필요하시다면 FAQ 상단 원본 소스의 링크를 이용하시기 바랍니다.

- **재가공하여 개인적으로만 사용해도 되나요?**


**아니오.** 토큰의 제작을 위해 사용한 상용소스는 제가 '개인적 이용 및 비영리적 최종산출물 목적'으로 구매하여 라이센스를 취득한 것이기에 이 토큰을 재가공하시면 개인적인 범위에서만 사용하시더라도 해당 상용소스의 라이센스를 위반하게 됩니다. 토큰에 쓰인 이미지 리소스를 사용하기 원하신다면 FAQ 상단의 원본 소스의 링크를 이용하시기 바랍니다.


# Designed By
양천일염/Yangsalt @kibkibe_trpg
https://github.com/kibkibe/roll20_api_scripts/edit/master/token_offensive_madness
